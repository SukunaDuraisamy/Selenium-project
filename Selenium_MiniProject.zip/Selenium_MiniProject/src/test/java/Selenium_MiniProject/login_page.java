package Selenium_MiniProject;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class login_page {
	WebDriver dr ;
	@FindBy(xpath = "//input[@name = 'user-name']")
	WebElement username;

	@FindBy(xpath = "//input[@name = 'password']")
	WebElement passwd;

	@FindBy(xpath = "//input[@name = 'login-button']")
	WebElement login;

	public login_page(WebDriver dr)
	{
		this.dr = dr;
		PageFactory.initElements(dr, this);
	}

	public void name(String name)
	{
		username.sendKeys(name);
	}

	public void pswd(String pswd)
	{
		passwd.sendKeys(pswd);
	}

	public void login()
	{
		login.click();
	}
}
