package Selenium_MiniProject;

import java.io.FileInputStream;
import java.io.IOException;

import java.time.Duration;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;


public class test001 
{
	static WebDriver dr;
	login_page lp;
	static product_page pp;
	String[][] testdata;

	static ExtentReports extent;
	static ExtentTest test;

	@BeforeMethod()
	public void bm()
	{
		dr.get("https://www.saucedemo.com/");
		lp = new login_page(dr);
		pp = new product_page(dr);
	}

	@BeforeClass()
	public void bc() throws IOException
	{

		extent = extendReport.getReportInstance("test001");
		test = extent.createTest("Test1 Started");
		dr = new FirefoxDriver();

		String filename = "SauceDemo.xlsx";
		String sheetname = "Sheet1";
		FileInputStream fis = new FileInputStream(filename);
		XSSFWorkbook wb = new XSSFWorkbook(fis);
		XSSFSheet sheet = wb.getSheet(sheetname);
		int row = sheet.getPhysicalNumberOfRows();
		int column = sheet.getRow(0).getPhysicalNumberOfCells();
		testdata = new String[row-1][column];
		for(int i=1;i<row;i++)
		{
			XSSFRow r = sheet.getRow(i);
			for(int j=0;j<column;j++)
			{
				XSSFCell cell = r.getCell(j);
				testdata[i-1][j] = cell.getStringCellValue();
			}
		}
		wb.close();
	}

	@DataProvider(name = "login")
	public Object[][] getData()
	{
		return testdata;
	}

	@Test(priority = 0)
	public void validation_url()
	{
		String url = dr.getCurrentUrl();
		Assert.assertEquals("https://www.saucedemo.com/",url);

	}

	@Test(priority = 1)
	public void validation_title()
	{
		String title = dr.getTitle();
		Assert.assertEquals("Swag Labs",title);
	}

	@Test(dataProvider = "login",priority = 2)
	public void Login_Credentials(String name,String psw)
	{
		
		test = extent.createTest("Open Browser");
		test.log(Status.INFO, "Browser opened and navigated to SauceDemo");
		
		System.out.println(name+" "+psw);
		lp.name(name);
		lp.pswd(psw);
		lp.login();
		String url = "https://www.saucedemo.com/inventory.html";
		if(url.equals(dr.getCurrentUrl()))
		{
			String atitle = pp.get_title();
			test.pass("Login Successfully Completed.");
			test.pass("Title validation passed");
			Assert.assertEquals("Products", atitle);
		}
		else
		{
			test.fail("Title validation Failed");
		}
		test001.product_add();
		test001.shipping_cart();
		test001.final_validation();
	}



	public static void product_add()
	{
		test001.details();
	}

	public static void details()
	{
		String url = "https://www.saucedemo.com/inventory.html";
		if(url.equals(dr.getCurrentUrl()))
		{
			String atitle = pp.get_title();
			test.pass("Login Successfully Completed.");
			test.pass("Title validation passed");
			Assert.assertEquals("Products", atitle);

			pp.filter();
			test.pass("Product Filtered");
			dr.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
			pp.add_product();
		}
		else
		{
			test.fail("Title validation Failed");
		}
	
	}

	
	public static void shipping_cart()
	{
		String cart = dr.findElement(By.className("title")).getText();
		if(cart.equals("Your Cart"))
		{
			String title = dr.findElement(By.xpath("//div[@class='inventory_item_name']")).getText();
			test.pass("Product Checked Successfully");
			Assert.assertEquals("Test.allTheThings() T-Shirt (Red)", title);
			pp.checkout();
		}
		else
		{
			test.fail("Product Checked unSuccessful");
		}
	}
	
	
	public static void final_validation()
	{
		String name = dr.findElement(By.className("title")).getText();
		if(name.equals("Checkout: Complete!"))
		{
			String validate = dr.findElement(By.className("complete-header")).getText();
			Assert.assertEquals("Thank you for your order!", validate);
			test.pass("Order placed successfully");
		}
		else
		{
			test.fail("Order placed unsuccessful");
		}
		test.log(Status.INFO,"All Validations are Completed");
		extent.flush();
	}

@AfterClass
public void am() 
{
	dr.quit();
}
	}