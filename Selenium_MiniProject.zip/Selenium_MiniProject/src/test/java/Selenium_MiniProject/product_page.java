package Selenium_MiniProject;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class product_page {
	WebDriver dr ;
	@FindBy(xpath="//span[@class='title']")
	WebElement title;
	
	public product_page(WebDriver dr)
	{
		this.dr = dr;
		PageFactory.initElements(dr, this);
	}
	
	public String get_title()
	{
		String str = dr.findElement(By.xpath("//span[@class='title']")).getText();
		return str;
	}
	
	public void filter()
	{
		WebElement we = dr.findElement(By.xpath("//select[@class='product_sort_container']"));
		Select sel = new Select(we);
		sel.selectByVisibleText("Name (Z to A)");
	}
	
	public void add_product()
	{
		dr.findElement(By.xpath("//div[@class='inventory_list']//div[1]//div[2]//div[2]//button[1]")).click();
		dr.findElement(By.xpath("//a[@class='shopping_cart_link']")).click();
	}
	
	public void checkout()
	{
		dr.findElement(By.id("checkout")).click();
		dr.findElement(By.id("first-name")).sendKeys("Vignesh");
		dr.findElement(By.id("last-name")).sendKeys("Duraisamy");
		dr.findElement(By.id("postal-code")).sendKeys("123456");
		dr.findElement(By.id("continue")).click();
		dr.findElement(By.name("finish")).click();
	}
}
