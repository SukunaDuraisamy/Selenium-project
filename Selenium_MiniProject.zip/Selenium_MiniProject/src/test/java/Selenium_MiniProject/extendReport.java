package Selenium_MiniProject;
import java.text.SimpleDateFormat;
import java.util.Date;
 
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

public class extendReport {
	public static ExtentReports getReportInstance(String reportName) {
		String timestamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
		String filePath = "test-output/" + reportName + "_" + timestamp + ".html";

		ExtentSparkReporter reporter = new ExtentSparkReporter(filePath);
		reporter.config().setReportName("SauceDemo Automation Report - " + reportName);
		reporter.config().setDocumentTitle("Test Results - " + reportName);

		ExtentReports extent = new ExtentReports();
		extent.attachReporter(reporter);
		extent.setSystemInfo("Tester", "Sukuna Duraisamy1");

		return extent;
	}
}